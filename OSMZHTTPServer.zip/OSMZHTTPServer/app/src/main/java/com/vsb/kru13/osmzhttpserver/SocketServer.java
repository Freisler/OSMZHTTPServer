package com.vsb.kru13.osmzhttpserver;

import android.os.Handler;
import android.util.Log;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class SocketServer extends Thread {

    private ServerSocket serverSocket;
    private final static int port = 12345;
    private boolean bRunning;
    private Handler messageHandler;

    public SocketServer(Handler messageHandler) {
        this.messageHandler = messageHandler;
    }


    public void close() {
        try {
            serverSocket.close();
        } catch (IOException e) {
            Log.d("SOCKETSERVER", "Error, probably interrupted in accept(), see log");
            e.printStackTrace();
        }
        bRunning = false;
    }

    public void run() {
        try {
            Log.d("SOCKETSERVER", "Creating Socket");
            serverSocket = new ServerSocket(port);
            bRunning = true;

            while (bRunning) {
                Log.d("SOCKETSERVER", "Socket Waiting for connection");
                Socket s = serverSocket.accept();

                ClientThread ct = new ClientThread(s, messageHandler);
                ct.start();


            }

        } catch (IOException e) {
            if (serverSocket != null && serverSocket.isClosed())
                Log.d("SOCKETSERVER", "Normal exit");
            else {
                Log.d("SOCKETSERVER", "Error");
                e.printStackTrace();
            }
        }
        finally {
            serverSocket = null;
            bRunning = false;
        }
    }


}


