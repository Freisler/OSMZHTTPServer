package com.vsb.kru13.osmzhttpserver;

import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.Comparator;

public class ClientThread extends Thread {
    private Socket s;
    private Handler messageHandler;
    private String filePath;
    private Message message;
    private String messageSuccess = "File URI: ";
    private long sizeOfFile;
    private String messageError = "Client error. File not found.";
    private String messageEnd = "Client closed the connection";

    public ClientThread(Socket s, Handler h) {
        this.s = s;
        this.messageHandler = h;
    }

    @Override
    public void run(){
            Log.d("SERVER_CLIENTTHREAD", "Thread started");
            //Log.d("SERVER_CLIENTTHREAD", "Socket Accepted");
            try {
                OutputStream o = s.getOutputStream();
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(o));
                BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));

                String tmp = in.readLine();

                if (tmp != null) {

                    Log.d("SERVER_CLIENTTHREAD", tmp);

                    String file;
                    if (tmp.startsWith("GET")) {
                        String[] parts = tmp.split(" ");
                        file = parts[1];

                        if (file.equals("/"))
                            file = "/index.html";
                    } else if(tmp.equals("putty1")) {
                        file = "/putty1.html";
                    } else if(tmp.equals("putty2")) {
                        file = "/putty2.html";
                    } else { //když napíšu do Putty nějaký blábol
                        file = "/x.html"; //název tak, aby to vyhodilo error 404
                    }

                    String sdPath = Environment.getExternalStorageDirectory().getAbsolutePath();
                    filePath = sdPath + file;

                    String[] fileType = file.split("\\.");

                    boolean fileExists = isFileExisting(filePath);
                    boolean isHtml = fileType[1].equals("html");

                    try {
                        Log.d("SERVER_CLIENTTHREAD", "Opening file " + filePath);
                        File f = new File(filePath);

                        FileInputStream fileIS = new FileInputStream(f);

                        //Log.d("SERVER","HTTP/1.0 200 OK");
                        out.write("HTTP/1.0 200 OK\n");

                        if (fileExists && isHtml)
                            out.write("Content-Type: text/html\n");
                        if (fileExists && !isHtml)
                            out.write("Content-Type: image/jpg, image/jpeg\n");

                        out.write("Content-Length: " + f.length() + "\n");
                        sizeOfFile = f.length();
                        out.write("\n");

                        out.flush();

                        int c;
                        byte[] buffer = new byte[1024];

                        while ((c = fileIS.read(buffer)) != -1) {
                            o.write(buffer, 0, c);
                        }

                        messageSuccess += filePath + "; Size: " + sizeOfFile + " B";
                        message = messageHandler.obtainMessage();
                        message.obj = messageSuccess;
                        messageHandler.sendMessage(message);

                        fileIS.close();
                        s.close();

                    } catch (FileNotFoundException e) {
                        Log.d("SERVER_CLIENTTHREAD", "HTTP/1.0 404 Not Found");
                        out.write("HTTP/1.0 404 Not Found\n\n");
                        out.write("<h1>404 File Not Found</h1>");
                        out.write("<p>Path: <b>" + filePath + "</b></p>");
                        out.write("<p>Files in directory: </p>");

                        File directory = new File(sdPath);
                        File[] files = directory.listFiles();

                        if (files != null && files.length > 1) {
                            Arrays.sort(files, new Comparator<File>() {
                                @Override
                                public int compare(File object1, File object2) {
                                    return object1.getName().compareTo(object2.getName());
                                }
                            });
                        }

                        out.write("<ul>");
                        for (int i = 0; i < files.length; i++) {
                            out.write("<li>" + files[i].getName() + "</li>");
                        }
                        out.write("</ul>");

                        out.flush();
                        s.close();

                        message = messageHandler.obtainMessage();
                        message.obj = messageError;
                        messageHandler.sendMessage(message);

                        Log.d("SERVER_CLIENTTHREAD", "Socket Closed");
                    }
                } else {
                    message = messageHandler.obtainMessage();
                    message.obj = messageEnd;
                    messageHandler.sendMessage(message);

                    s.close();
                    Log.d("SERVER_CLIENTTHREAD", "Socket Closed");
                }
            } catch (IOException e) {
                Log.d("SERVER_CLIENTTHREAD","IOException");
            } finally {

            }
    }

    private boolean isFileExisting(String filePath) {
        File file = new File(filePath);
        return file.exists();
    }
}
